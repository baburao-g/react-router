import React from "react";
import {
  BrowserRouter as Router,
  Route,
  Link,
  NavLink,
  Switch
} from "react-router-dom";

class ContactUS extends React.Component {
  render() {
    return (
      <div>
        <h1>Contact US</h1>
        baburao.gadekar@gmail.com
      </div>
    );
  }
}

export default ContactUS;
