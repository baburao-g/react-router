import React from "react";

class AboutUS extends React.Component {
  render() {
    return (
      <div>
        <h1>About Us</h1>Its Me..!
      </div>
    );
  }
}

export default AboutUS;
